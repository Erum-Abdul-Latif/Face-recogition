# Store this code in 'app.py' file
from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re
from datetime import date
from werkzeug.utils import secure_filename
import urllib.request
import os


app = Flask(__name__)
app.debug = True
app.run()
UPLOAD_FOLDER = 'static/uploads/'
app.secret_key = 'your secret key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'erum'
app.config['MYSQL_PASSWORD'] = '!@#123QWERTYqwerty'
app.config['MYSQL_DB'] = 'pumpjack_dataworks'

mysql = MySQL(app)

UPLOAD_FOLDER = 'static/uploads/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
 
@app.route('/login', methods =['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM admin_login WHERE email = % s AND password = % s', (email, password, ))
        account = cursor.fetchone()
        if account:
            session['loggedin'] = True
            session['id'] = account['email']
            session['username'] = account['password']
            msg = 'Logged in successfully !'
            return render_template('admin_Navigation.html', msg = msg)
        else:
            msg = 'Incorrect email / password !'
    return render_template('login.html', msg = msg)

@app.route('/logout')
def logout():
	session.pop('loggedin', None)
	session.pop('id', None)
	session.pop('username', None)
	return redirect(url_for('login'))

@app.route('/register', methods =['GET', 'POST'])
def register():
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'email' in request.form and 'password' in request.form :
		username = request.form['username']
		email = request.form['email']
		password = request.form['password']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute('SELECT * FROM admin_login WHERE user_name = % s', (username, ))
		account = cursor.fetchone()
		if account:
			msg = 'Account already exists !'
		elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
			msg = 'Invalid email address !'
		elif not re.match(r'[A-Za-z0-9]+', username):
			msg = 'Username must contain only characters and numbers !'
		elif not username or not password or not email:
			msg = 'Please fill out the form !'
		else:
			cursor.execute('INSERT INTO admin_login VALUES (NULL, % s, % s, % s)', (username, email, password, ))
			mysql.connection.commit()
			msg = 'You have successfully registered !'
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	return render_template('register.html', msg = msg)

@app.route('/add_new_employee', methods =['GET', 'POST'])

def add_new_employee():
    msg=''      
    if request.method == 'POST' and 'firstname' in request.form and 'lastname' in request.form and 'employee_id' in request.form and 'cnic' in request.form and 'designation' in request.form and 'department' in request.form and 'arrival_time' in request.form and 'departure_time' in request.form and 'joining_date' in request.form and 'status' in request.form and 'email' in request.form and 'contact_number' in request.form and 'address' in request.form and 'file' in request.files:
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        employee_id = request.form['employee_id']
        cnic = request.form['cnic']
        designation = request.form['designation']
        department = request.form['department']
        arrival_time = request.form['arrival_time']
        departure_time = request.form['departure_time']
        joining_date = request.form['joining_date']
        status = request.form['status']
        email = request.form['email']
        contact_number = request.form['contact_number']
        address = request.form['address']
        file= request.files['file']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM employee WHERE employee_id = % s', (employee_id, ))
        account = cursor.fetchall()
        if account:
            msg = 'Employee ID already exists !'
		
        else:
            file = request.files['file']            
            filename = secure_filename(file.filename)
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            #print('upload_image filename: ' + filename)
            "INSERT INTO customers (name, address) VALUES (%s, %s)"
            cursor.execute('INSERT INTO employee VALUES (NULL, % s, % s, % s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)', (firstname, lastname, employee_id, cnic, designation, department, arrival_time, departure_time, joining_date, status, email, contact_number, address, filename))
            mysql.connection.commit()
            msg = 'You have successfully inserted !'
    elif request.method == 'POST':
        msg = 'Please fill out the form !'
    return render_template('add_new_employee.html', msg = msg)
    
	
@app.route('/view_employees', methods =['GET', 'POST'])
def view_employees():
	cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
	cursor.execute("select employee_id,first_name,last_name from employee")
	account=cursor.fetchall()
	return render_template("view_employees.html",data=account)
	
@app.route('/complete_details/<int:id>', methods =['GET', 'POST'])
def complete_details(id):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("select first_name,last_name,employee_id,cnic,designation,department,arrival_time,departure_time,joining_date,status,email,contact_number,address,photo from employee where employee_id= % s", (id,))
    account = cursor.fetchall()
    return render_template("complete_details.html",data=account)

@app.route('/admin_navigation', methods =['GET', 'POST'])
def admin_navigation():
	return render_template("admin_Navigation.html")

@app.route('/attendance_report')
def attendance_report():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("select * from attendance_report where status='present' && date= % s", (date.today(),))
    present=cursor.rowcount
    
    cursor.execute("select * from attendance_report where status='absent' && date= % s", (date.today(),))
    absent=cursor.rowcount
    
    cursor.execute("select * from attendance_report where late_in='Yes' && date= % s", (date.today(),))
    latein=cursor.rowcount

    cursor.execute("select * from attendance_report where early_go='Yes' && date= % s", (date.today(),))
    earlygo=cursor.rowcount

    cursor.execute("select employee_id,employee_name,date,status,shift_arrivaltime,arrival_time,shift_departuretime,departure_time,hours_worked,late_in,early_go from attendance_report where date= % s", (date.today(),))
    account = cursor.fetchall()


    return render_template("attendance_report.html", num_present=present, num_absent=absent,num_latein=latein,num_earlygo=earlygo,data=account)
	
@app.route('/view_attendance_details/<int:id>', methods =['GET', 'POST'])
def view_attendance_details(id):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("select * from attendance_report where status='present' && employee_id= % s", (id,)) 
    present=cursor.rowcount
    
    cursor.execute("select * from attendance_report where status='absent' && employee_id= % s", (id,))   
    absent=cursor.rowcount
    
    cursor.execute("select * from attendance_report where late_in='yes' && employee_id= % s", (id,))   
    latein=cursor.rowcount
    
    cursor.execute("select * from attendance_report where early_go='yes' && employee_id= % s", (id,))   
    earlygo=cursor.rowcount

    cursor.execute("select employee_id,employee_name,date,status,shift_arrivaltime,arrival_time,shift_departuretime,departure_time,hours_worked,late_in,early_go from attendance_report where employee_id= % s", (id,))
    account = cursor.fetchall()

    return render_template("view_attendance_report.html", num_present=present, num_absent=absent, num_late_in=latein, num_early_go=earlygo, data=account)

@app.route('/update/<int:id>', methods =['GET', 'POST'])
def update(id):
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute("select first_name,last_name,employee_id,cnic,designation,department,arrival_time,departure_time,joining_date,status,email,contact_number,address from employee where employee_id= % s", (id,))
    account = cursor.fetchall()
    return render_template('update_profile.html',data=account)


@app.route('/update_profile', methods =['GET', 'POST'])
def update_profile():
    if request.method == 'POST' and 'firstname' in request.form and 'lastname' in request.form and 'employee_id' in request.form and 'cnic' in request.form and 'designation' in request.form and 'department' in request.form and 'arrival_time' in request.form and 'departure_time' in request.form and 'joining_date' in request.form and 'status' in request.form and 'email' in request.form and 'contact_number' in request.form and 'address' in request.form:
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        employee_id = request.form['employee_id']
        cnic = request.form['cnic']
        designation = request.form['designation']
        department = request.form['department']
        arrival_time = request.form['arrival_time']
        departure_time = request.form['departure_time']
        joining_date = request.form['joining_date']
        status = request.form['status']
        email = request.form['email']
        contact_number = request.form['contact_number']
        address = request.form['address']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute("update employee set first_name= %s,last_name= %s,employee_id=%s,designation=%s,department=%s,arrival_time=%s,departure_time=%s,joining_date=%s,status=%s,contact_number= %s,email= %s,cnic= %s,address= %s where employee_id= %s",(firstname, lastname, employee_id, designation, department, arrival_time, departure_time, joining_date, status, contact_number, email, cnic, address, employee_id,))
        mysql.connection.commit()
    return redirect(url_for('add_new_employee'))

@app.route('/user_credential', methods =['GET', 'POST'])
def user_credential():
    if request.method == 'POST' and 'employee_id' in request.form and 'password' in request.form :
        employee_id = request.form['employee_id']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('INSERT INTO employee_login VALUES (NULL, % s, % s)', (employee_id, password, ))
        mysql.connection.commit()
			
    return render_template('user_credential.html')

if __name__ == '__main__':
   app.run()
